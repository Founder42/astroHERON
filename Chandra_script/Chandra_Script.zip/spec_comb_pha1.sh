#!/bin/sh
#===================================================
#tg_spec_1-0-1.sh
version=1.1.1
author="Fangzheng Shi"
copyrights="All rights reserved. 2017-2027"
manual="Please execute the script and give the following 2 parameters in sequence: 1. ADDRESS of your working directory where the src/bkg spectra and rmf/arf files reside, 2.SOURCE NAME."
#===============================================

#cd $1

#ls *ph2* > pha.lis
#ls *garf* > arf.lis
#ls *.rmf > rmf.lis


#for osid in $evtname
#do
  #ls ${osid}*ph2.fits > pha_tmp.lis
  #ls ${osid}*garf* > arf_tmp.lis
  #ls ${osid}*.rmf > rmf_tmp.lis
  punlearn combine_spectra
  pset combine_spectra src_spectra=@pha_$2.lis
  pset combine_spectra src_arfs=@arf_$2.lis
  pset combine_spectra src_rmfs=@rmf_$2.lis
  #pset combine_grating_spectra garm=HEG
  pset combine_spectra bkg_spectra=@bkg_$2.lis
  pset combine_spectra mode=h
  pset combine_spectra clobber=yes
  pset combine_spectra outroot=$2
  combine_spectra

#done
